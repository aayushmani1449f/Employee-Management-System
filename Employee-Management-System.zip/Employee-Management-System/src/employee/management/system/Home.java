package employee.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Home extends JFrame implements ActionListener {

    JButton view, add, update, remove, buildResume, viewResume, findJobs, exit;

    Home() {

        setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/home.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1120, 630, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 1120, 630);
        add(image);

        JLabel heading = new JLabel("Employee Management And Training System");
        heading.setBounds(520, 20, 600, 40);
        heading.setFont(new Font("Raleway", Font.BOLD, 25));
        image.add(heading);

        add = new JButton("Add New User");
        add.setBounds(650, 80, 150, 40);
        add.addActionListener(this);
        image.add(add);

        view = new JButton("View Users");
        view.setBounds(820, 80, 150, 40);
        view.addActionListener(this);
        image.add(view);

        update = new JButton("Update User Details");
        update.setBounds(650, 140, 150, 40);
        update.addActionListener(this);
        image.add(update);

        remove = new JButton("Remove User");
        remove.setBounds(820, 140, 150, 40);
        remove.addActionListener(this);
        image.add(remove);

        buildResume = new JButton("Build Resume");
        buildResume.setBounds(650, 200, 150, 40);
        buildResume.addActionListener(this);
        image.add(buildResume);

        viewResume = new JButton("View Resume");
        viewResume.setBounds(820, 200, 150, 40);
        viewResume.addActionListener(this);
        image.add(viewResume);

        findJobs = new JButton("Find Jobs");
        findJobs.setBounds(735, 260, 150, 40); // Adjusted position
        findJobs.addActionListener(this);
        image.add(findJobs);

        exit = new JButton("Exit");
        exit.setBounds(735, 320, 150, 40); // Adjusted position
        exit.addActionListener(this);
        image.add(exit);

        setSize(1120, 630);
        setLocation(250, 100);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == add) {
            setVisible(false);
            new AddEmployee();
        } else if (ae.getSource() == view) {
            setVisible(false);
            new ViewEmployee();
        } else if (ae.getSource() == update) {
            setVisible(false);
            new ViewEmployee();
        } else if (ae.getSource() == remove) {
            setVisible(false);
            new RemoveEmployee();
        } else if (ae.getSource() == buildResume) {
            setVisible(false);
            new Resume();
        } else if (ae.getSource() == viewResume) {
            // Handle the "View Resume" button action
            // You can add your code here
        } else if (ae.getSource() == findJobs) {
            // Handle the "Find Jobs" button action
            // You can add your code here
        } else if (ae.getSource() == exit) {
            System.exit(0);
        }
    }

    public static void main(String[] args) {
        new Home();
    }
}
