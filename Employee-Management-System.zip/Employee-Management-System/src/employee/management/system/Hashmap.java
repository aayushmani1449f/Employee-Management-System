package employee.management.system;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Hashmap extends RemoveEmployee {
    private Map<String, User> userMap;

    public Hashmap() {
        this.userMap = new HashMap<>();
    }

    public void addUser(User user) {
        userMap.put(user.getId(), user);
    }

    public void removeUser(String userId) {
        if (userMap.containsKey(userId)) {
            userMap.remove(userId);
            System.out.println("User with ID " + userId + " removed successfully.");
        } else {
            System.out.println("User with ID " + userId + " not found.");
        }
    }

    public void displayUsers() {
        System.out.println("List of Users:");
        for (Map.Entry<String, User> entry : userMap.entrySet()) {
            System.out.println("ID: " + entry.getKey() + ", Name: " + entry.getValue().getName());
        }
    }

    public static void main(String[] args) {
        UserManager userManager = new UserManager();
        Scanner scanner = new Scanner(System.in);

        userManager.addUser(new User("1", "John"));
        userManager.addUser(new User("2", "Alice"));
        userManager.addUser(new User("3", "Bob"));

        userManager.displayUsers();
        System.out.print("Enter the ID of the user to remove: ");
        String userIdToRemove = scanner.nextLine();
        userManager.removeUser(userIdToRemove);
        userManager.displayUsers();
    }
}
class User {
    private String id;
    private String name;

    public User(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}

