package employee.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;

public class Resume extends JFrame implements ActionListener {
    private JTextField nameField, designationField, contactField, emailField, addressField, educationField,
            experienceField, skillsField;

    public Resume() {
        setTitle("Resume Builder");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(9, 2, 10, 10));

        panel.add(new JLabel("Employee Name:"));
        nameField = new JTextField();
        panel.add(nameField);

        panel.add(new JLabel("Designation:"));
        designationField = new JTextField();
        panel.add(designationField);

        panel.add(new JLabel("Contact Number:"));
        contactField = new JTextField();
        panel.add(contactField);

        panel.add(new JLabel("Email:"));
        emailField = new JTextField();
        panel.add(emailField);

        panel.add(new JLabel("Address:"));
        addressField = new JTextField();
        panel.add(addressField);

        panel.add(new JLabel("Education:"));
        educationField = new JTextField();
        panel.add(educationField);

        panel.add(new JLabel("Experience:"));
        experienceField = new JTextField();
        panel.add(experienceField);

        panel.add(new JLabel("Skills:"));
        skillsField = new JTextField();
        panel.add(skillsField);

        JButton generateButton = new JButton("Generate Resume");
        generateButton.addActionListener(this);
        panel.add(generateButton);

        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(this);
        panel.add(cancelButton);

        add(panel);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // Handle button click event
        if (e.getActionCommand().equals("Generate Resume")) {
            generateResume();
        } else if (e.getActionCommand().equals("Cancel")) {
            openHome(); // Open the Home class
            dispose();  // Close the current window
        }
    }

    private void generateResume() {
        String employeeName = nameField.getText();
        String designation = designationField.getText();
        String contactNumber = contactField.getText();
        String email = emailField.getText();
        String address = addressField.getText();
        String education = educationField.getText();
        String experience = experienceField.getText();
        String skills = skillsField.getText();

        String resumeContent = "---------- Resume ----------\n\n" +
                "Name: " + employeeName + "\n" +
                "Designation: " + designation + "\n" +
                "Contact Number: " + contactNumber + "\n" +
                "Email: " + email + "\n" +
                "Address: " + address + "\n\n" +
                "Education: " + education + "\n\n" +
                "Experience: " + experience + "\n\n" +
                "Skills: " + skills + "\n\n" +
                "---------------------------";

        System.out.println(resumeContent);

        // Save the resume to a file
        saveToFile(resumeContent);
    }

    private void saveToFile(String content) {
        try (FileWriter writer = new FileWriter("resume.txt")) {
            writer.write(content);
            System.out.println("\nResume saved to 'resume.txt'");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void openHome() {
        // Open the Home class
        SwingUtilities.invokeLater(() -> new Home());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Resume());
    }
}
