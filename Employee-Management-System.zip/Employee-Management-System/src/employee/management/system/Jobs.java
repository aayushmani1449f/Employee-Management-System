package employee.management.system;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Jobs extends JFrame implements ActionListener {

    JComboBox<String> skillsBox, salaryRangeBox, designationBox;
    JButton searchButton, closeButton;

    Jobs() {
        setLayout(null);
        setTitle("Job Search");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Skills input
        JLabel skillsLabel = new JLabel("Skills:");
        skillsLabel.setBounds(50, 30, 100, 30);
        add(skillsLabel);

        String[] skillsOptions = {"Java", "Python", "JavaScript", "C++", "React", "Angular", "Node.js"};
        skillsBox = new JComboBox<>(skillsOptions);
        skillsBox.setBounds(160, 30, 150, 30);
        add(skillsBox);

        // Salary Range input
        JLabel salaryLabel = new JLabel("Salary Range(INR):");
        salaryLabel.setBounds(50, 80, 100, 30);
        add(salaryLabel);

        String[] salaryOptions = {"< 50k", "50k - 100k", "100k - 150k", "> 150k"};
        salaryRangeBox = new JComboBox<>(salaryOptions);
        salaryRangeBox.setBounds(160, 80, 150, 30);
        add(salaryRangeBox);

        // Designation input
        JLabel designationLabel = new JLabel("Designation:");
        designationLabel.setBounds(50, 130, 100, 30);
        add(designationLabel);

        String[] designationOptions = {"Software Engineer", "Web Developer", "Data Scientist", "Product Manager"};
        designationBox = new JComboBox<>(designationOptions);
        designationBox.setBounds(160, 130, 150, 30);
        add(designationBox);

        // Search button
        searchButton = new JButton("Search");
        searchButton.setBounds(80, 180, 100, 30);
        searchButton.addActionListener(this);
        add(searchButton);

        // Close button
        closeButton = new JButton("Close");
        closeButton.setBounds(220, 180, 100, 30);
        closeButton.addActionListener(this);
        add(closeButton);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == searchButton) {
            // Perform search based on input (demo only)
            String selectedSkills = (String) skillsBox.getSelectedItem();
            String selectedSalaryRange = (String) salaryRangeBox.getSelectedItem();
            String selectedDesignation = (String) designationBox.getSelectedItem();

            // Display demo results
            JOptionPane.showMessageDialog(this, "Searching for jobs with the following criteria:\n" +
                    "Skills: " + selectedSkills + "\nSalary Range: " + selectedSalaryRange +
                    "\nDesignation: " + selectedDesignation + "\n\nDemo Results:\n1. Software Engineer\n2. Web Developer");
        } else if (ae.getSource() == closeButton) {
            // Close the current page and open Home class
            setVisible(false);
            new Home();
        }
    }

    public static void main(String[] args) {
        new Jobs();
    }
}

